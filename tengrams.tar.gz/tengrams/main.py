from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import numpy as np

df = pd.read_csv('train.csv')
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

#print(df)

df['is_train'] = np.random.uniform(0, 1, len(df)) <= .85

train, test = df[df['is_train']==True], df[df['is_train']==False]

print('Number of observations in the training data:', len(train))
print('Number of observations in the test data:',len(test))


features = df.columns[:9]

print(features)
y = pd.factorize(train['class'])[0]
clf = RandomForestClassifier(n_jobs=2, random_state=0)

clf.fit(train[features], y)

preds= clf.predict(test[features])

c = clf.predict(test[features])[0:10]




print(list(zip(train[features], clf.feature_importances_)))

#print("Train Accuracy :: ", accuracy_score(train_y, trained_model.predict(train_x)))
print("Test Accuracy  :: ", accuracy_score(test, preds))
