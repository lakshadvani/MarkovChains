#Code for extracting a markov chain from system calls
#Lakad>>
#
from numpy import array
import csv
from operator import itemgetter
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook

royal_probability = 0


memory = {}
def _learn_key(key, value):
    if key not in memory:
           memory[key] = []
    memory[key].append(value)

def learn(bigrams):


    for bigram in bigrams:
        for i in range(0,len(bigram)-1):

            _learn_key(bigram[i], bigram[i+1])
tensor = []


ll = []
troika = []

#print(troika)

tensor = []
with open('normal1_tracer.csv', 'r') as csvfile:

    csvreader = csv.reader(csvfile)
    next(csvreader)
    i = 0
    for row in csvreader:
        i = i +1
        print(row)
        num = row


        tensor.append([i,row])
        ll.append(row)

time = []
call = []
leng = i
for i in ll:

    call.append(i)
call = [item for sublist in call for item in sublist]
from collections import Counter
Q = Counter(call).items()



percentages = {x: (float(y) / len(call)) for x, y in Q}
q = {}
for name, pct in percentages.items():
    q[name] = pct


tokens = call
bigrams = [call[i:i+2] for i in range(0, len(call), 1)]

#print(tengrams)


#print(bigrams)
###
m = learn(bigrams)
from collections import Counter


new = {}
for k,v in memory.items():
    c=Counter()
    for letter in v:
        c[letter] += 1
    v = [(i, c[i] / len(v)) for i in c]
    new[k] = v



royal_probability = 0
flag = 0
flog = 0
for i in bigrams:
  if(len(i)>1):
    for k,v in new.items():
         if(i[0] in k):
             nucor = new[k]
             test = dict(nucor) 
             for j in range(1,len(i)-1):
                if i[j] in test:
                    flag = 1 + flag
  else:
      pass
print(flag/leng)
#print(new)
#print(new)
#####################################################################################################################################################
ll1 = []
tensor1= []
time1 = []
call1 = []
with open('normal4_tracer.csv', 'r') as csvfile1:
    csvreader1 = csv.reader(csvfile1)
    next(csvreader1)
    i = 0
    for row in csvreader1:
        i = i +1
        tensor1.append([i,row])
        ll1.append(row)
#print(ll1)
for i in ll1:

    call1.append(i)
prob_seq = []
tokens1 = call1
tengrams1 = call1
leng = len(tengrams1)
#print(tengrams1)
royal_probability = 0
flag = 0
flog = 0

yankee_white = []
flog = 0
count = 0
for i in tengrams1:

    seq = []

    probs = []
    z = 1
    i = [item for sublist in i for item in sublist]

    if(i[0] in q):
         init = q[i[0]]
    else:
         init = 0
         
    if(i[0] in new):
       probs = dict(new[i[0]])
       for k in range(1,len(i)-1):
           if(i[k] in probs):
               count = count+1
               seq.append(probs[i[k]])

           else:
               seq.append(0)
               flog = flog+1
               count = count+1
    else:
         flog = flog+1

    for ii in seq:
         z = ii*z
    yankee = z*init
    #print(sum(seq))
    yankee_white.append(yankee)
print(sum(yankee_white)/leng)
print(count,flog)
print((count-flog)/count)

