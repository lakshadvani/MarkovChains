import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import numpy as np
df = pd.read_csv('train.csv').values
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn import metrics
import seaborn as sns; sns.set()
from sklearn.cross_validation import train_test_split
##
from sklearn.ensemble import AdaBoostClassifier
import numpy
import matplotlib.pyplot as plt
import pandas
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error

from sklearn.grid_search import GridSearchCV
import pandas as pd
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from evolutionary_search import EvolutionaryAlgorithmSearchCV
x = df[:, :-1]

y = df[:, -1]


test_size = 0.10

x_training, x_test, y_training, y_test = train_test_split(x,y,test_size=test_size)




import lightgbm as lgb
lgb_train = lgb.Dataset(x_training, y_training)
lgb_eval = lgb.Dataset(x_test, y_test, reference=lgb_train)
params = {}

import lightgbm as lgb

ind_params = {
    'seed': 32,
    'n_estimators': 200,
    'learning_rate': 0.1,
    'nthread': 1
}
params = {'max_depth': (4, 6, 8),
          'subsample': (0.75, 0.8, 0.9, 1.0),
          'colsample_bytree': (0.75, 0.8, 0.9, 1.0),
          'num_leaves': (12, 16, 36, 48, 54, 60, 80, 100)
         }

clf2 = EvolutionaryAlgorithmSearchCV(estimator=lgb.LGBMClassifier(**ind_params),
                                   params=params,
                                   scoring="accuracy",
                                   cv=5,
                                   verbose=1,
                                   population_size=50,
                                   gene_mutation_prob=0.10,
                                   gene_crossover_prob=0.5,
                                   tournament_size=5,
                                   generations_number=100,
                                   n_jobs=8)
print(clf2.fit(x_training, y_training))

'''
params = {

    #'n_estimators': 200,
    'learning_rate': 0.3,
    'nthread': 8,
    'max_depth': 500,
    'subsample': 0.9,
    #'colsample_bytree': 1,
    'num_leaves': 18,
    'n_estimators': 112,
    'reg_lambda': 1.3, 
    'reg_alpha': 1.3,
    'gene_mutation_prob':0.10,
    'bagging_fraction': 0.95,
    'bagging_freq': 1,
    'bagging_seed': 4,
    'feature_fraction': 0.9,
    'feature_fraction_seed': 9




}
gbm = lgb.train(params,
                lgb_train,
                )
y_pred = gbm.predict(x_test, num_iteration=gbm.best_iteration)
accuracy = accuracy_score(y_test, y_pred.round())
print("Accuracy LightGBM: %.2f%%" % (accuracy * 100.0))
'''
'''
model = RandomForestClassifier(n_estimators=200)
model.fit(x_training, y_training)
ypred = model.predict(x_test)
print(metrics.classification_report(ypred, y_test))
errors = abs(ypred - y_test)
print('Mean Absolute Error:', round(np.mean(errors), 2), 'degrees.')
'''
